// ===== Tema claro / oscuro =====
const botonTema = document.getElementById("tema");

function aplicarTema(oscuro) {
  document.body.classList.toggle("oscuro", oscuro);
  botonTema.textContent = oscuro ? "☀️" : "🌙";
  try { localStorage.setItem("tema", oscuro ? "oscuro" : "claro"); } catch (e) {}
}

let temaGuardado = null;
try { temaGuardado = localStorage.getItem("tema"); } catch (e) {}
aplicarTema(temaGuardado === "oscuro");

botonTema.addEventListener("click", () => {
  aplicarTema(!document.body.classList.contains("oscuro"));
});

// ===== Barra de progreso de lectura =====
const barra = document.getElementById("barra");

function actualizarBarra() {
  const total = document.documentElement.scrollHeight - window.innerHeight;
  const porcentaje = total > 0 ? (window.scrollY / total) * 100 : 0;
  barra.style.width = porcentaje + "%";
}
window.addEventListener("scroll", actualizarBarra, { passive: true });
window.addEventListener("resize", actualizarBarra);
actualizarBarra();

// ===== Tarjetas de enfoques =====
const detalles = {
  nativo: "✅ Mejor rendimiento y acceso completo a las APIs del sistema. ❌ Dos bases de código y mayor costo de desarrollo.",
  multi: "✅ Un solo código para Android e iOS, desarrollo más rápido. ❌ Algunas funciones nativas requieren puentes o plugins.",
  web: "✅ Sin tiendas de apps, se actualiza al instante. ❌ Acceso limitado al hardware, sobre todo en iOS."
};

const tarjetas = document.querySelectorAll(".tarjeta");
const detalle = document.getElementById("detalle");

tarjetas.forEach((tarjeta) => {
  tarjeta.addEventListener("click", () => {
    tarjetas.forEach((t) => t.classList.remove("activa"));
    tarjeta.classList.add("activa");
    detalle.textContent = detalles[tarjeta.dataset.tipo];
  });
});

// ===== Checklist de primeros pasos =====
const casillas = document.querySelectorAll("#checklist input[type='checkbox']");
const resumenPasos = document.getElementById("resumen-pasos");

function actualizarResumen() {
  const hechas = [...casillas].filter((c) => c.checked).length;
  casillas.forEach((c) => c.closest("li").classList.toggle("hecho", c.checked));
  resumenPasos.textContent =
    hechas === casillas.length
      ? "🎉 ¡Completaste todos los pasos!"
      : `Llevas ${hechas} de ${casillas.length} pasos.`;
  try {
    localStorage.setItem("pasos", JSON.stringify([...casillas].map((c) => c.checked)));
  } catch (e) {}
}

try {
  const guardado = JSON.parse(localStorage.getItem("pasos") || "[]");
  casillas.forEach((c, i) => { c.checked = !!guardado[i]; });
} catch (e) {}

casillas.forEach((c) => c.addEventListener("change", actualizarResumen));
actualizarResumen();

// ===== Quiz =====
const preguntas = [
  {
    texto: "¿Qué lenguaje se usa en Flutter?",
    opciones: ["Dart", "Swift", "Kotlin"],
    correcta: 0
  },
  {
    texto: "¿Qué herramienta es necesaria para compilar apps de iOS?",
    opciones: ["Android Studio", "Xcode", "Git"],
    correcta: 1
  },
  {
    texto: "¿Qué enfoque permite instalar una web como si fuera una app?",
    opciones: ["Nativo", "Multiplataforma", "PWA"],
    correcta: 2
  }
];

const elPregunta = document.getElementById("pregunta");
const elOpciones = document.getElementById("opciones");
const elResultado = document.getElementById("resultado");
const botonSiguiente = document.getElementById("siguiente");

let indice = 0;
let puntos = 0;

function mostrarPregunta() {
  const p = preguntas[indice];
  elPregunta.textContent = `${indice + 1}/${preguntas.length} · ${p.texto}`;
  elOpciones.innerHTML = "";
  elResultado.textContent = "";
  botonSiguiente.hidden = true;

  p.opciones.forEach((texto, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = texto;
    b.addEventListener("click", () => responder(i));
    elOpciones.appendChild(b);
  });
}

function responder(i) {
  const p = preguntas[indice];
  const botones = elOpciones.querySelectorAll("button");
  botones.forEach((b, n) => {
    b.disabled = true;
    if (n === p.correcta) b.classList.add("correcta");
  });

  if (i === p.correcta) {
    puntos++;
    elResultado.textContent = "✅ ¡Correcto!";
  } else {
    botones[i].classList.add("incorrecta");
    elResultado.textContent = "❌ Incorrecto.";
  }

  botonSiguiente.textContent = indice < preguntas.length - 1 ? "Siguiente" : "Ver resultado";
  botonSiguiente.hidden = false;
}

botonSiguiente.addEventListener("click", () => {
  if (indice < preguntas.length - 1) {
    indice++;
    mostrarPregunta();
  } else {
    elPregunta.textContent = `Resultado final: ${puntos} de ${preguntas.length}`;
    elOpciones.innerHTML = "";
    elResultado.textContent = puntos === preguntas.length ? "🏆 ¡Excelente!" : "Sigue practicando 💪";
    botonSiguiente.textContent = "Reintentar";
    botonSiguiente.onclick = () => {
      indice = 0;
      puntos = 0;
      botonSiguiente.onclick = null;
      mostrarPregunta();
    };
  }
});

mostrarPregunta();
