TUTORIAL DE DESARROLLO MÓVIL
============================

Página web interactiva que explica los fundamentos del desarrollo móvil.

ESTRUCTURA
----------
tutorial_desarrollo_movil/
├── index.html        Contenido de la página
├── css/styles.css    Estilos (tema claro y oscuro, diseño adaptable)
├── js/app.js         Interactividad
└── README.txt        Este archivo

CÓMO ABRIRLO EN VISUAL STUDIO CODE
----------------------------------
1. Abre VS Code.
2. Menú Archivo > Abrir carpeta... y elige "tutorial_desarrollo_movil".
3. Instala la extensión "Live Server" (de Ritwick Dey).
4. Haz clic derecho sobre index.html > "Open with Live Server".
   También puedes abrir index.html directamente con doble clic en tu navegador.

FUNCIONES
---------
- Navegación por secciones con barra de progreso de lectura.
- Botón para cambiar entre tema claro y oscuro (se recuerda).
- Tarjetas de enfoques: clic para ver pros y contras.
- Lista de primeros pasos con contador (se guarda en el navegador).
- Quiz de 3 preguntas con puntuación final.

PERSONALIZACIÓN
---------------
- Colores: variables al inicio de css/styles.css (:root y body.oscuro).
- Preguntas del quiz: arreglo "preguntas" en js/app.js.
- Textos de pros y contras: objeto "detalles" en js/app.js.
